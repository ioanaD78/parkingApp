import React, { Component } from 'react';
import {
    StyleSheet,
    Text, Image,
    View, TouchableOpacity, Vibration, TextInput,
} from 'react-native';

class Home extends Component {
    render() {
        return (
            <View style={styles.container}>

            </View>
        )
    }
}

export default Home;

const styles = StyleSheet.create({
    container: {
        backgroundColr: '#F5FCFF',
        flex: 1,
        justifyContent: 'center',
    },
});

