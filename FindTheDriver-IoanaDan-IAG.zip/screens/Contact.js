import * as React from 'react';
import { Text, View, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { windowHeight } from '../components/utils/WindowDimensions';

import Input from '../components/form/Input';
import InputMsg from '../components/form/InputMsg';
import LoginButton from '../components/form/LoginButton';

const Login = ({ navigation }) => {

    return (
        <View style={styles.container}>

            <Text style={styles.text}> Contact us! </Text>

            <Input
                placeholderText="Name"
                iconType="person-circle-outline"
                keyboardType="email-address"
                autoCapitalize="none"
            />
            <Input
                placeholderText="E-mail"
                iconType="mail-outline"
            />
            <InputMsg
                placeholderText="Message"
                iconType="chatbox-ellipses-outline"
            />

            <LoginButton
                buttonTitle="Send"
                onPress={() => alert('Sent')}
            />
        </View>
    );
};

export default Login;

const styles = StyleSheet.create({
    container: {
        alignItems: 'center',
        padding: 15,
        marginTop: windowHeight / 10,
    },
    text: {
        fontSize: 30,
        marginBottom: 10,
        color: '#34548a',
    },
    navButton: {
        marginTop: 15,
    },
});